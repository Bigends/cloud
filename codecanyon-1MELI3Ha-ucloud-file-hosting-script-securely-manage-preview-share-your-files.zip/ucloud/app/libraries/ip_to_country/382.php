<?php $entries = array(
array('38273024','38797311','KZ'),
array('3825205248','3841982463','ZZ'),
);