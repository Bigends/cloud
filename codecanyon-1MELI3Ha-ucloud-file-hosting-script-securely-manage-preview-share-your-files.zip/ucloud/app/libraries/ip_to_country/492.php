<?php $entries = array(
array('49283072','49807359','DE'),
);