<?php $entries = array(
array('58720256','67108863','US'),
array('587202560','595591167','US'),
);