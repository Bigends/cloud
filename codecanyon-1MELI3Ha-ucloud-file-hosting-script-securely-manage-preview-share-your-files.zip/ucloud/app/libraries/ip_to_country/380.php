<?php $entries = array(
array('3808428032','3825205247','ZZ'),
);