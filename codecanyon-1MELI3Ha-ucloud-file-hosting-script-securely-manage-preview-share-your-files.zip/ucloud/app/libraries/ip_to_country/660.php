<?php $entries = array(
array('660602880','661127167','CN'),
);