<?php $entries = array(
array('46661632','47185919','DE'),
);