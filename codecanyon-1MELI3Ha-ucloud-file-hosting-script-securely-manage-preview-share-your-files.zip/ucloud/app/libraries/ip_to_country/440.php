<?php $entries = array(
array('44040192','45088767','DE'),
);