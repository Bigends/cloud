<?php $entries = array(
array('3992977408','4009754623','ZZ'),
);