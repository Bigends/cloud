<?php $entries = array(
array('50331648','58720255','US'),
array('503316480','520093695','US'),
);