<?php $entries = array(
array('37748736','38273023','SE'),
array('3774873600','3791650815','ZZ'),
);