<?php $entries = array(
array('486539264','503316479','US'),
);