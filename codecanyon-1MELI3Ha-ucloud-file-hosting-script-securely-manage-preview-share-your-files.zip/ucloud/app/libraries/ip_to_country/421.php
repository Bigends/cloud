<?php $entries = array(
array('4211081216','4227858431','ZZ'),
);