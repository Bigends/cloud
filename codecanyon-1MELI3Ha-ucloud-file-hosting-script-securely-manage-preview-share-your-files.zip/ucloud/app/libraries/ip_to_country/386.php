<?php $entries = array(
array('386924544','387055615','CA'),
);