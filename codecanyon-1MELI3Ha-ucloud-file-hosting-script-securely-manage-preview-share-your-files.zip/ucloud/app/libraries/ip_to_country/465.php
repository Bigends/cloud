<?php $entries = array(
array('465043456','465567743','CN'),
array('465567744','467664895','CN'),
);