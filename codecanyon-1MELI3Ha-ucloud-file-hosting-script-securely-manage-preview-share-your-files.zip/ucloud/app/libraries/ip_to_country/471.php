<?php $entries = array(
array('47185920','47710207','DE'),
);