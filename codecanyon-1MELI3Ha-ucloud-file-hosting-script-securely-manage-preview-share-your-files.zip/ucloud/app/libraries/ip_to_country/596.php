<?php $entries = array(
array('596115456','596639743','US'),
array('596639744','597164031','US'),
);